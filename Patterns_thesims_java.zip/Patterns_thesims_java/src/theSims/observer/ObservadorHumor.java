package theSims.observer;

public interface ObservadorHumor {
    void atualizar(String novoHumor);
}
