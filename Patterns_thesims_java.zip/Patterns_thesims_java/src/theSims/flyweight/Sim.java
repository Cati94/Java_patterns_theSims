package theSims.flyweight;

public class Sim {
    String nome;
    public Sim(String nome) { this.nome = nome; }
}