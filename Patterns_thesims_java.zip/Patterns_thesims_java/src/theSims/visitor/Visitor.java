package theSims.visitor;

public interface Visitor {
    void visitarAdulto(Adulto adulto);
    void visitarCrianca(Crianca crianca);
}
