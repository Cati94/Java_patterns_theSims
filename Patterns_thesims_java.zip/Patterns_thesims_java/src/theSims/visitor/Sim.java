package theSims.visitor;

public interface Sim {
    void aceitar(Visitor v);
}
