package theSims.command;

public interface Comando {
    void executar();
    void desfazer();
}
