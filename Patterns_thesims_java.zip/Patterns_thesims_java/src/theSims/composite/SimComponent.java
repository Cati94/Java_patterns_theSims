package theSims.composite;

public interface SimComponent {
    void executarAcao();
}
