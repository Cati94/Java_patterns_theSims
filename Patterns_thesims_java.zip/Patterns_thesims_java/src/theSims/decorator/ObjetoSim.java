package theSims.decorator;

public interface ObjetoSim {
    void usar();
}
