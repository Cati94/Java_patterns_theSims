package theSims.decorator;

public class TVSimples implements ObjetoSim {
    public void usar () {
        System.out.println("Assistindo TV com canais básicos.");
    }
}

