package theSims.state;

public class HungryState implements SimState {
    public void act() {
        System.out.println("O Sim está com fome e procura comida.");
    }
}

