package theSims.state;

public interface SimState {
    void act();
}
