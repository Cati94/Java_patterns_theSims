package theSims.state;

public class HappyState implements SimState {
    public void act() {
        System.out.println("O Sim está feliz e a dançar!");
    }
}

