package theSims.state;

public class TiredState implements SimState {
    public void act() {
        System.out.println("O Sim está cansado e vai dormir.");
    }
}
