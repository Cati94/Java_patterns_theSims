package theSims.facade;

public class Frigorifico{
    public void pegarIngredientes(String prato) {
        System.out.println("Pegando ingredientes para " + prato);
    }
}