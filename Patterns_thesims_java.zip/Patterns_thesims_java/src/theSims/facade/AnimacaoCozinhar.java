package theSims.facade;

public class AnimacaoCozinhar {
    public void executar(String prato) {
        System.out.println("Animando preparo de " + prato);
    }
}