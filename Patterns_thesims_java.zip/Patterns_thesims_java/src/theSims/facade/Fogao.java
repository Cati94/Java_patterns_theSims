package theSims.facade;

public class Fogao {
    public void aquecer() { System.out.println("Fogão aquecendo..."); }
}