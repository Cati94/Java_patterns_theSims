package theSims.Mediator;

interface Mediador {
    void enviarMensagem(String mensagem, Sim participante);
}