package theSims.Interpreter;

public interface Expressao {
    void interpretar(Sim sim);
}