package theSims.Interpreter;

public class Sim {
    String nome;
    int fome;
    int energia;

    public Sim(String nome, int fome, int energia) {
        this.nome = nome;
        this.fome = fome;
        this.energia = energia;
    }
}