package theSims.bridge;

public interface Estilo {
    void aplicarEstilo(String objeto);
}

