package theSims.AbstractFactory;

interface Casa {
    void descricao();
}
