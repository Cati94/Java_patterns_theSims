package theSims.AbstractFactory;

interface Sim {
    void descricao();
}