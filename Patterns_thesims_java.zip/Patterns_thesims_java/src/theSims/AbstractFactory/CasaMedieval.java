package theSims.AbstractFactory;

class CasaMedieval implements Casa {
    public void descricao() {
        System.out.println("Castelo medieval com muralhas e torres.");
    }
}