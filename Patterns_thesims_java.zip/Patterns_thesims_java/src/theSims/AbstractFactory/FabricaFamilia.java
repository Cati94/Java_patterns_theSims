package theSims.AbstractFactory;

interface FabricaFamilia {
    Sim criarSim();
    Casa criarCasa();
}