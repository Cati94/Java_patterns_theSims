package theSims.AbstractFactory;

class SimMedieval implements Sim {
    public void descricao() {
        System.out.println("Sim medieval com roupas de época e espada.");
    }
}