package theSims.AbstractFactory;

class CasaModerna implements Casa {
    public void descricao() {
        System.out.println("Casa moderna com arquitetura minimalista.");
    }
}