package theSims.AbstractFactory;

class SimModerno implements Sim {
    public void descricao() {
        System.out.println("Sim moderno com roupas casuais e smartphone.");
    }
}