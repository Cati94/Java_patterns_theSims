package theSims.adapter;

public interface InteracaoNova {

	void interagir();
}
