package theSims.strategy;

public class Swim implements RelaxStrategy {
    public void relax() {
        System.out.println("O Sim está a nadar na piscina.");
    }
}

