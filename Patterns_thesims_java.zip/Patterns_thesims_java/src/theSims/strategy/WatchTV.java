package theSims.strategy;

public class WatchTV implements RelaxStrategy {
    public void relax() {
        System.out.println("O Sim está a relaxar a ver TV.");
    }
}

