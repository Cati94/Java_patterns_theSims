package theSims.strategy;

public interface RelaxStrategy {
    void relax();
}
