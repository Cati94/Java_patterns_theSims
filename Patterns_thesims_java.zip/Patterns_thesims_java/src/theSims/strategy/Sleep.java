package theSims.strategy;

public class Sleep implements RelaxStrategy {
    public void relax() {
        System.out.println("O Sim foi dormir.");
    }
}
