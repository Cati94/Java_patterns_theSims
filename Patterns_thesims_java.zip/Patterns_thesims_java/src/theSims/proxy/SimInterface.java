package theSims.proxy;

public interface SimInterface {
    void verEstado();
    void interagir(); // Apenas disponível no SimReal
}
